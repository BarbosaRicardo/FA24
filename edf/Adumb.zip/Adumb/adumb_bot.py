import sys
import time
import requests
from datetime import datetime
from playwright.sync_api import sync_playwright

def log(msg):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}")

def send_logout_email():
    try:
        log("Sending logout email...")
        res = requests.post(
            "https://api.emailjs.com/api/v1.0/email/send",
            json={
                "service_id": "service_68nsjgw",
                "template_id": "template_rbgedad",
                "user_id": "hphFpgVEUcKrue_fe",
                "template_params": {
                    "name": "Adumb Bot",
                    "email": "ricardo.barbosa@edf-re.com",
                    "message": f"The Adumb bot logged out at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                }
            },
            headers={"Content-Type": "application/json"}
        )
        log(f"Email response: {res.status_code} - {res.text}")
        if res.status_code == 200:
            log("Logout email sent")
        else:
            log("Failed to send logout email")
    except Exception as e:
        log(f"Email exception: {e}")

def login(page):
    page.fill("#username", "adumb")
    page.fill("#password", "password")
    page.click("input[type='submit']")
    log("Attempted login")
    page.wait_for_selector("#logout", timeout=5000)
    log("Logged in successfully")

def run_bot():
    with sync_playwright() as p:
        log("Launching browser...")
        browser = p.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-gpu",
                "--disable-dev-shm-usage",
                "--disable-setuid-sandbox",
                "--single-process"
            ]
        )
        context = browser.new_context()
        page = context.new_page()
        try:
            log("Navigating to site...")
            page.goto("https://adumb.netlify.app", timeout=15000)
            login(page)

            while True:
                try:
                    if page.is_closed():
                        log("Browser window closed unexpectedly.")
                        break

                    dispatch_form = page.query_selector("#dispatchForm")
                    if not dispatch_form:
                        log("Waiting for dispatches...")
                        time.sleep(3)
                        continue

                    radios = dispatch_form.query_selector_all("input[type='radio']")
                    if radios:
                        for radio in radios:
                            radio.check()
                        log(f"Selected {len(radios)} radio buttons")

                        submit_btn = dispatch_form.query_selector("button.ack-button")
                        if submit_btn:
                            submit_btn.click()
                            log("Clicked Submit button")
                        else:
                            log("Submit button not found")
                    else:
                        log("No radio buttons found")

                    time.sleep(3)
                except Exception as inner_err:
                    log(f"Error in main loop: {inner_err}")
                    time.sleep(5)

        except KeyboardInterrupt:
            log("Ctrl+C detected — logging out...")
            try:
                if not page.is_closed():
                    try:
                        if page.is_visible("#logout"):
                            page.click("#logout")
                            log("Clicked logout button")
                            time.sleep(1)
                        else:
                            log("Logout button not visible.")
                    except Exception as inner:
                        log(f"Inner logout handling error: {inner}")
                else:
                    log("Page already closed before logout.")
            except Exception as e:
                log(f"Error while logging out: {e}")
            finally:
                try:
                    send_logout_email()
                except Exception as email_err:
                    log(f"Failed to send logout email: {email_err}")
                try:
                    browser.close()
                except Exception as close_err:
                    log(f"Error closing browser: {close_err}")
                log("Browser closed. Exiting...")
                sys.exit(0)

if __name__ == "__main__":
    run_bot()